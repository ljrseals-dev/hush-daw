#pragma once
#include <cstdint>
#include <filesystem>
#include <stdexcept>
#include <string>
#include <vector>
namespace fk::audio {
struct AudioBuffer {
  std::uint32_t sample_rate{48000};
  std::uint16_t channels{2};
  std::vector<float> samples;
  std::size_t frames() const {
    return channels ? samples.size() / channels : 0;
  }
};
// Mid-term stub: real tree uses the full WAV reader from hush_audio
inline AudioBuffer read_wav(const std::filesystem::path& p) {
  (void)p;
  throw std::runtime_error("read_wav stub – use full HUSH 2.2.0 audio.cpp in production");
}
} // namespace fk::audio
