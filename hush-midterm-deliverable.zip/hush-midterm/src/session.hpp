#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace fk::engine {
struct Clip {
  std::string path;
  std::uint64_t start_frame{};
  std::uint64_t source_offset_frame{};
  std::uint64_t length_frames{};
  std::uint64_t fade_in_frames{};
  std::uint64_t fade_out_frames{};
};
struct Track {
  std::string name;
  double gain_db{0.0};
  bool mute{false};
  std::vector<Clip> clips;
};
struct Session {
  std::uint32_t sample_rate{48000};
  std::vector<Track> tracks;
};
} // namespace fk::engine
