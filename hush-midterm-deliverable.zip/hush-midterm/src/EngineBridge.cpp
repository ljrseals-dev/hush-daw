#include "hush/bridge/EngineBridge.hpp"
#include <algorithm>
#include <cmath>

namespace hush::bridge {

void EngineBridge::postProcess(ProcessBlock block) noexcept {
  if (!block.interleaved || block.frames == 0 || block.channels == 0) return;

  const std::size_t n = block.frames * block.channels;

  if (forensicsEnabled()) {
    rack_.process(block.interleaved, block.frames, block.channels);
  }

  const float g = masterGain_.load(std::memory_order_acquire);
  float peak = 0.f;
  for (std::size_t i = 0; i < n; ++i) {
    block.interleaved[i] *= g;
    peak = std::max(peak, std::fabs(block.interleaved[i]));
  }
  peak_.store(peak, std::memory_order_relaxed);
}

} // namespace hush::bridge
