#pragma once
#include <string>
#include <utility>
namespace fk {
struct Status {
  bool ok{true};
  std::string msg;
  static Status success() { return {}; }
  static Status fail(std::string m) { return {false, std::move(m)}; }
  explicit operator bool() const { return ok; }
};
template <typename T>
struct Result {
  Status status;
  T value{};
  bool ok() const { return status.ok; }
};
} // namespace fk
