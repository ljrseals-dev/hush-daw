#include "hush/forensic/ForensicRack.hpp"
#include <algorithm>
#include <cmath>

namespace hush::forensic {

void ForensicRack::process(float* interleaved, std::size_t frames, std::uint16_t channels) noexcept {
  if (!interleaved || frames == 0 || channels == 0 || bypassed()) return;
  const std::size_t n = frames * channels;

  // Work on a temporary mono mix for analysis-style slots, then re-apply
  // For simplicity and RT safety we process each channel independently
  // with the same coefficients.

  auto p0 = params(Slot::SpectralDenoise);
  auto p1 = params(Slot::HissReduction);
  auto p2 = params(Slot::ClickRemoval);
  auto p3 = params(Slot::HumEliminator);

  if (p0.enabled) processSpectral(interleaved, n, p0.amount);
  if (p1.enabled) processHiss(interleaved, n, p1.amount);
  if (p2.enabled) processClick(interleaved, n, p2.amount);
  if (p3.enabled) processHum(interleaved, n, p3.amount, p3.secondary);
}

// Spectral de-noise: gentle high-frequency attenuation when amount is high
// (placeholder for full subband noise reduction)
void ForensicRack::processSpectral(float* x, std::size_t n, float amount) noexcept {
  const float keep = 1.f - 0.35f * amount;
  for (std::size_t i = 0; i < n; ++i) {
    // simple 1-pole lowpass blend
    static thread_local float lp = 0.f;
    lp += 0.15f * (x[i] - lp);
    x[i] = x[i] * keep + lp * (1.f - keep);
  }
}

// Hiss reduction: high-shelf cut
void ForensicRack::processHiss(float* x, std::size_t n, float amount) noexcept {
  const float a = 0.05f + 0.4f * amount; // coefficient
  for (std::size_t i = 0; i < n; ++i) {
    float hf = x[i] - hissState_;
    hissState_ += a * hf;
    x[i] = x[i] - hf * amount * 0.7f;
  }
}

// Click removal: soft median-like spike suppressor
void ForensicRack::processClick(float* x, std::size_t n, float amount) noexcept {
  const float thresh = 0.4f - 0.3f * amount;
  for (std::size_t i = 0; i < n; ++i) {
    float d = x[i] - clickPrev_;
    if (std::fabs(d) > thresh) {
      x[i] = clickPrev_ + d * (1.f - amount * 0.85f);
    }
    clickPrev_ = x[i];
  }
}

// Hum eliminator: simple notch around secondary-controlled frequency
// secondary 0 = 50 Hz-ish, 1 = 60 Hz-ish (normalized)
void ForensicRack::processHum(float* x, std::size_t n, float amount, float freqNorm) noexcept {
  // Very light IIR notch approximation
  const float r = 1.f - 0.02f * amount;
  const float w = 0.006f + 0.002f * freqNorm; // crude digital frequency
  for (std::size_t i = 0; i < n; ++i) {
    float y = x[i] - humState2_ + r * (humState_ * 2.f * std::cos(w) - humState2_ * r);
    humState2_ = humState_;
    humState_  = y * 0.01f + x[i] * 0.99f; // slow state
    x[i] = x[i] * (1.f - amount * 0.5f) + y * (amount * 0.5f);
  }
}

} // namespace hush::forensic
