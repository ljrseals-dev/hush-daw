# Apply mid-term integration onto full HUSH 2.2.0-reconciled

1. Copy into the reconciled tree:
   - include/hush/forensic/ForensicRack.hpp
   - include/hush/bridge/EngineBridge.hpp
   - src/ForensicRack.cpp
   - src/EngineBridge.cpp
   - Replace src/audio_engine.hpp with this package’s version
     (or merge the forensic API + bridge_ member)
   - Patch src/audio_engine.cpp process() tail to call:
       bridge_.setMasterGain(master_gain_.load(...));
       bridge_.postProcess({out, count, channels});
       output_peak_.store(bridge_.outputPeak(), ...);

2. CMake – extend hush_realtime:
   add_library(hush_realtime STATIC
     src/audio_engine.cpp src/midi.cpp src/plugin_host.cpp src/portaudio_backend.cpp
     src/ForensicRack.cpp src/EngineBridge.cpp)
   target_include_directories(hush_realtime PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)

3. UI knobs:
   engine.set_rack_slot(hush::forensic::Slot::SpectralDenoise, on, amount, 0.f);
   // same for HissReduction, ClickRemoval, HumEliminator

4. Optional Engine 0.1.0:
   cmake -DHUSH_ENGINE_ROOT=/path/to/HUSH-Engine-0.1.0/hush ...
