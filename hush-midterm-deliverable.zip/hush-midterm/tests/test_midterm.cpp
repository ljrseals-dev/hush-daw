#include "audio_engine.hpp"
#include <cmath>
#include <iostream>
#include <vector>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::cerr << "FAIL " #c " @" << __LINE__ << "\n"; ++fails; } } while(0)

int main() {
  std::cout << "HUSH mid-term integration tests\n";

  hush::rt::AudioEngine eng;

  // Rack API on AudioEngine
  using S = hush::forensic::Slot;
  eng.set_forensics_enabled(true);
  eng.set_rack_slot(S::SpectralDenoise, true, 0.55f);
  eng.set_rack_slot(S::HissReduction,   true, 0.40f);
  eng.set_rack_slot(S::ClickRemoval,    true, 0.65f);
  eng.set_rack_slot(S::HumEliminator,   true, 0.50f, 0.3f);

  auto p = eng.rack_slot(S::ClickRemoval);
  CHECK(p.enabled);
  CHECK(std::fabs(p.amount - 0.65f) < 0.02f);
  CHECK(eng.forensics_enabled());

  // process() with no session → silence path still runs bridge
  std::vector<float> out(256, 0.f);
  auto n = eng.process(out.data(), 128, 2);
  CHECK(n == 0); // not playing / empty

  // Direct bridge path (as used inside process after render)
  for (auto& v : out) v = 0.2f;
  out[50] = 1.0f;
  eng.bridge().postProcess({out.data(), 128, 2});
  CHECK(eng.bridge().outputPeak() > 0.f);
  CHECK(eng.output_peak() >= 0.f); // engine peak may still be 0 until process played

  // Slot names match UI
  CHECK(std::string(hush::forensic::slotName(S::SpectralDenoise)) == "Spectral De-noise");
  CHECK(std::string(hush::forensic::slotName(S::HumEliminator)) == "Hum Eliminator");

  if (fails) { std::cerr << fails << " failures\n"; return 1; }
  std::cout << "ALL TESTS PASSED\n";
  return 0;
}
