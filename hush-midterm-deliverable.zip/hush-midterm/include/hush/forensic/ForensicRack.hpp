#pragma once
/**
 * HUSH Forensic Rack – maps the four rack plugins in the 2.2.0 Reconciled UI
 *
 *   1. Spectral De-noise
 *   2. Hiss Reduction
 *   3. Click Removal
 *   4. Hum Eliminator
 *
 * These run as insert processors. Heavy analysis stays off the audio thread;
 * only smoothed coefficients reach the realtime path (via the Engine command queue).
 */

#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace hush::forensic {

enum class Slot : int {
  SpectralDenoise = 0,
  HissReduction   = 1,
  ClickRemoval    = 2,
  HumEliminator   = 3,
  Count           = 4
};

inline const char* slotName(Slot s) {
  switch (s) {
    case Slot::SpectralDenoise: return "Spectral De-noise";
    case Slot::HissReduction:   return "Hiss Reduction";
    case Slot::ClickRemoval:    return "Click Removal";
    case Slot::HumEliminator:   return "Hum Eliminator";
    default:                    return "Unknown";
  }
}

struct SlotParams {
  bool  enabled   = false;
  float amount    = 0.5f;   // 0..1  (threshold / reduction)
  float secondary = 0.0f;   // e.g. reduction depth, frequency
};

/**
 * Lightweight realtime processors for the four rack slots.
 * These are intentionally simple and allocation-free so they can run
 * inside the Engine / AudioEngine process() callback.
 */
class ForensicRack {
public:
  void setParams(Slot slot, const SlotParams& p) noexcept {
    const int i = static_cast<int>(slot);
    if (i < 0 || i >= static_cast<int>(Slot::Count)) return;
    params_[static_cast<size_t>(i)].store(pack(p), std::memory_order_release);
  }

  SlotParams params(Slot slot) const noexcept {
    const int i = static_cast<int>(slot);
    if (i < 0 || i >= static_cast<int>(Slot::Count)) return {};
    return unpack(params_[static_cast<size_t>(i)].load(std::memory_order_acquire));
  }

  /// Process interleaved stereo (or mono) in-place. Realtime-safe.
  void process(float* interleaved, std::size_t frames, std::uint16_t channels) noexcept;

  /// Bypass all slots
  void setBypass(bool b) noexcept { bypass_.store(b, std::memory_order_release); }
  bool bypassed() const noexcept { return bypass_.load(std::memory_order_acquire); }

private:
  static std::uint64_t pack(const SlotParams& p) noexcept {
    // bit0 = enabled, bits 1-31 = amount*1e6, bits 32-63 = secondary*1e6
    std::uint64_t v = p.enabled ? 1ull : 0ull;
    v |= (static_cast<std::uint64_t>(std::lround(std::clamp(p.amount, 0.f, 1.f) * 1e6f)) & 0x7fffffffull) << 1;
    v |= (static_cast<std::uint64_t>(std::lround(std::clamp(p.secondary, 0.f, 1.f) * 1e6f)) & 0xffffffffull) << 32;
    return v;
  }
  static SlotParams unpack(std::uint64_t v) noexcept {
    SlotParams p;
    p.enabled   = (v & 1ull) != 0;
    p.amount    = static_cast<float>((v >> 1) & 0x7fffffffull) / 1e6f;
    p.secondary = static_cast<float>((v >> 32) & 0xffffffffull) / 1e6f;
    return p;
  }

  void processSpectral(float* x, std::size_t n, float amount) noexcept;
  void processHiss(float* x, std::size_t n, float amount) noexcept;
  void processClick(float* x, std::size_t n, float amount) noexcept;
  void processHum(float* x, std::size_t n, float amount, float freqNorm) noexcept;

  std::array<std::atomic<std::uint64_t>, 4> params_{};
  std::atomic<bool> bypass_{false};

  // Simple filter state (per-slot, mono path)
  float hissState_  = 0.f;
  float humState_   = 0.f;
  float humState2_  = 0.f;
  float clickPrev_  = 0.f;
};

} // namespace hush::forensic
