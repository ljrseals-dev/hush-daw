#pragma once
/**
 * Bridge: HUSH Engine 0.1.0  +  Forensic Rack  →  2.2.0-style process path
 *
 * Keeps the 2.2.0 AudioEngine session/clip model as the source of samples,
 * then optionally runs the live forensic rack (and Engine master bus)
 * on the rendered block before it reaches the device.
 */

#include "hush/forensic/ForensicRack.hpp"
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace hush::bridge {

struct ProcessBlock {
  float* interleaved = nullptr;   // pre-filled by session renderer
  std::size_t frames = 0;
  std::uint16_t channels = 2;
};

/**
 * Owns the ForensicRack and applies it after session render.
 * In a full integration this class also holds a hush::Engine instance
 * and routes track gains through its SPSC command queue.
 */
class EngineBridge {
public:
  EngineBridge() = default;

  forensic::ForensicRack& rack() noexcept { return rack_; }
  const forensic::ForensicRack& rack() const noexcept { return rack_; }

  /// Enable / disable the entire forensic insert chain
  void setForensicsEnabled(bool on) noexcept { forensicsOn_.store(on, std::memory_order_release); }
  bool forensicsEnabled() const noexcept { return forensicsOn_.load(std::memory_order_acquire); }

  /// Master gain (linear)
  void setMasterGain(float g) noexcept { masterGain_.store(g, std::memory_order_release); }
  float masterGain() const noexcept { return masterGain_.load(std::memory_order_acquire); }

  /**
   * Final stage of the realtime path.
   * Call after 2.2.0 AudioEngine::process has filled the buffer.
   * Applies forensic rack (if enabled) then master gain. Realtime-safe.
   */
  void postProcess(ProcessBlock block) noexcept;

  /// Peak meter (linear, updated every process)
  float outputPeak() const noexcept { return peak_.load(std::memory_order_relaxed); }

private:
  forensic::ForensicRack rack_;
  std::atomic<bool>  forensicsOn_{true};
  std::atomic<float> masterGain_{1.0f};
  std::atomic<float> peak_{0.f};
};

} // namespace hush::bridge
