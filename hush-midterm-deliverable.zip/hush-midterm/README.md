# HUSH Mid-term – AudioEngine × Forensic Rack

Concrete integration (not examples only):

- `AudioEngine` owns `EngineBridge`
- `process()` ends with forensic rack + master gain
- UI binds via `set_rack_slot(Slot::…, enabled, amount, secondary)`

```bash
cmake -S . -B build && cmake --build build
./build/hush_midterm_tests   # or copy to /tmp if noexec
./build/hush_midterm_demo
```

See `docs/APPLY_TO_FULL_TREE.md` to land this on the full 2.2.0-reconciled sources.
