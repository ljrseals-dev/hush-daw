#include "audio_engine.hpp"
#include <iostream>
int main() {
  hush::rt::AudioEngine eng;
  eng.set_forensics_enabled(true);
  using S = hush::forensic::Slot;
  eng.set_rack_slot(S::SpectralDenoise, true, 0.55f);
  eng.set_rack_slot(S::HissReduction, true, 0.40f);
  eng.set_rack_slot(S::ClickRemoval, true, 0.65f);
  eng.set_rack_slot(S::HumEliminator, true, 0.50f, 0.3f);

  std::cout << "HUSH mid-term – AudioEngine + Forensic Rack integrated\n";
  for (int i = 0; i < 4; ++i) {
    auto s = static_cast<S>(i);
    auto p = eng.rack_slot(s);
    std::cout << "  " << hush::forensic::slotName(s)
              << "  on=" << p.enabled << " amount=" << p.amount << "\n";
  }
  std::cout << "process() ends with bridge_.postProcess() – ready for PortAudio callback.\n";
  return 0;
}
