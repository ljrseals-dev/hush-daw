HUSH 2.2.0 — Linux x86-64 prebuilt binaries

Built from the included source in this package using GNU C++ 14.2.0 and CMake in Release mode. The CLI binary is `hush`; the optional X11 desktop executable is `hush_gui`. Both include the native processor rack implementation.

Run `./hush help` to see supported commands. `hush_gui` requires an X11 display and system X11 runtime libraries.

PortAudio hardware output was not enabled in this build and no physical audio device test was performed. Do not interpret these binaries as proof of hardware playback, recording, or monitoring support.

Rebuild on your own host with:
  cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DHUSH_BUILD_X11_GUI=ON
  cmake --build build -j2
  ctest --test-dir build --output-on-failure

The real-time processor rack is off by default. Processor `Noise` is an experimental downward expander, not a spectral denoiser. `Match`, `Edges`, `Album`, and `A/B` are not executed in the real-time callback in this release.
