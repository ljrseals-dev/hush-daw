HUSH 2.2.0 Linux x86_64 prebuilt executables

hush      Command-line application
hush_gui  Native X11 GUI; accepts a session path: ./hush_gui path/to/session.fks

Build environment used: GCC 14.2, CMake, Linux x86_64. GUI executable dynamically links
libX11.so.6 and libportaudio.so.2; install your distribution's X11 and PortAudio runtime
packages if missing. No network access or dependency fetching is performed by CMake.

The GUI needs a session file. Create one with:
  ./hush session-new demo.fks 48000 120
Then launch:
  ./hush_gui demo.fks
