# HUSH quick start (Linux x86_64)

## Run the supplied binaries
```sh
cd prebuilt-linux-x86_64
./hush --help
./hush session-new demo.fks 48000 120
./hush_gui demo.fks
```

The GUI requires a working X11 desktop session. The GUI dynamically links X11 and PortAudio. If the binary reports a missing shared library, install that library from your Linux distribution.

## Rebuild from source
Install CMake, GCC or Clang, X11 development headers/libraries, and PortAudio development/runtime files. Then run:
```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DHUSH_BUILD_X11_GUI=ON -DHUSH_ENABLE_PORTAUDIO=ON -DBUILD_TESTING=ON
cmake --build build -j4
ctest --test-dir build --output-on-failure -E hush_module_tests
```
See `BUILD_STATUS_2026-10-15.md` for exact validation and limitations.
