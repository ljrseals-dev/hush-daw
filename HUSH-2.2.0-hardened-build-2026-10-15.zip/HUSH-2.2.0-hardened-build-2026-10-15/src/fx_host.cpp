#include "fx_host.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

namespace hush::fx {
namespace {
constexpr std::size_t ix(Module m) noexcept { return static_cast<std::size_t>(m); }
constexpr float kPi = 3.14159265358979323846f;
float sane(float x) noexcept { return std::isfinite(x) ? std::clamp(x, 0.0f, 1.0f) : 0.0f; }
}
const std::array<ModuleInfo, static_cast<std::size_t>(Module::Count)>& list_modules() noexcept {
  static constexpr std::array<ModuleInfo, static_cast<std::size_t>(Module::Count)> items{{
    {Module::Hum, "Hum", Maturity::Tested, true},
    {Module::Smooth, "Smooth", Maturity::Tested, true},
    {Module::Sibilance, "Sibilance", Maturity::Tested, true},
    {Module::Level, "Level", Maturity::Tested, true},
    {Module::Peak, "Peak", Maturity::Tested, true},
    {Module::Noise, "Noise", Maturity::Experimental, true},
    {Module::Match, "Match", Maturity::Experimental, false},
    {Module::Edges, "Edges", Maturity::OfflineOnly, false},
    {Module::Album, "Album", Maturity::HostTool, false},
    {Module::AB, "A/B", Maturity::HostTool, false}
  }};
  return items;
}
ProcessorRack::ProcessorRack() noexcept { prepare(48000); }
void ProcessorRack::prepare(std::uint32_t sr) noexcept { sample_rate_ = std::clamp<std::uint32_t>(sr, 8000, 768000); reset(); }
void ProcessorRack::reset() noexcept {
  for (auto& s : state_) s = {0.0f, 0.0f};
  hum_x1_.fill(0); hum_x2_.fill(0); hum_y1_.fill(0); hum_y2_.fill(0);
  smooth_lp_.fill(0); deess_lp_.fill(0); deess_env_.fill(0); level_env_.fill(0); output_peak_.store(0, std::memory_order_relaxed);
}
void ProcessorRack::set_params(Module m, Params p) noexcept {
  if (ix(m) >= params_.size()) return;
  // Keep real-time experimental noise processing explicitly opt-in; unsupported offline/host
  // modules are never run in the callback even if a client mistakenly enables them.
  auto& a = params_[ix(m)];
  a.amount.store(sane(p.amount), std::memory_order_release);
  a.secondary.store(sane(p.secondary), std::memory_order_release);
  a.enabled.store(p.enabled, std::memory_order_release);
}
Params ProcessorRack::params(Module m) const noexcept {
  if (ix(m) >= params_.size()) return {};
  const auto& a = params_[ix(m)];
  return {a.enabled.load(std::memory_order_acquire), a.amount.load(std::memory_order_acquire), a.secondary.load(std::memory_order_acquire)};
}
void ProcessorRack::process(float* x, std::size_t frames, std::uint16_t channels) noexcept {
  if (!x || (channels != 1 && channels != 2) || frames > std::numeric_limits<std::size_t>::max() / channels) return;
  const auto on = [this](Module m) noexcept { return params_[ix(m)].enabled.load(std::memory_order_acquire); };
  const auto amt = [this](Module m) noexcept { return params_[ix(m)].amount.load(std::memory_order_acquire); };
  const bool hum = on(Module::Hum), smooth = on(Module::Smooth), deess = on(Module::Sibilance);
  const bool level = on(Module::Level), peak = on(Module::Peak), noise = on(Module::Noise);
  const float hum_amt = amt(Module::Hum), smooth_amt = amt(Module::Smooth), deess_amt = amt(Module::Sibilance);
  const float level_amt = amt(Module::Level), peak_amt = amt(Module::Peak), noise_amt = amt(Module::Noise);
  // Stable RBJ-style notch coefficients at the local mains fundamental (60 Hz in US; 50 Hz
  // where sample-rate/parameter policy is changed in a future configuration API).
  const float f0 = 60.0f, w = 2.0f * kPi * f0 / static_cast<float>(sample_rate_);
  const float alpha = std::sin(w) * 0.025f;
  const float b0 = 1.0f / (1.0f + alpha), b1 = -2.0f * std::cos(w) * b0, b2 = b0;
  const float a1 = b1, a2 = (1.0f - alpha) * b0;
  const float lp_a = std::clamp(1.0f - std::exp(-2.0f * kPi * (18000.0f - smooth_amt * 14500.0f) / static_cast<float>(sample_rate_)), 0.001f, 0.99f);
  const float deess_lp_a = std::clamp(1.0f - std::exp(-2.0f * kPi * 4200.0f / static_cast<float>(sample_rate_)), 0.001f, 0.99f);
  const float env_a = 1.0f - std::exp(-1.0f / (0.012f * static_cast<float>(sample_rate_)));
  const float level_a = 1.0f - std::exp(-1.0f / (0.180f * static_cast<float>(sample_rate_)));
  float maxp = 0.0f;
  for (std::size_t i = 0; i < frames; ++i) for (std::uint16_t c = 0; c < channels; ++c) {
    const auto k = i * channels + c;
    float v = std::isfinite(x[k]) ? x[k] : 0.0f;
    if (hum && hum_amt > 0.0f) {
      const float notch = b0*v + b1*hum_x1_[c] + b2*hum_x2_[c] - a1*hum_y1_[c] - a2*hum_y2_[c];
      hum_x2_[c] = hum_x1_[c]; hum_x1_[c] = v; hum_y2_[c] = hum_y1_[c]; hum_y1_[c] = notch;
      v += (notch - v) * hum_amt;
    }
    if (smooth || deess) smooth_lp_[c] += lp_a * (v - smooth_lp_[c]);
    if (smooth) v += (smooth_lp_[c] - v) * smooth_amt * 0.45f;
    if (deess) {
      deess_lp_[c] += deess_lp_a * (v - deess_lp_[c]);
      const float high = v - deess_lp_[c];
      deess_env_[c] += env_a * (std::abs(high) - deess_env_[c]);
      const float reduction = std::clamp((deess_env_[c] - 0.12f) * deess_amt * 2.8f, 0.0f, 0.75f);
      v -= high * reduction;
    }
    if (noise) {
      // Conservative experimental downward expander. Disabled by default; never claims spectral denoising.
      const float mag = std::abs(v), threshold = 0.0005f + (1.0f - noise_amt) * 0.02f;
      const float gain = mag < threshold ? std::clamp(mag / threshold, 0.05f, 1.0f) : 1.0f;
      v *= gain;
    }
    if (level) {
      level_env_[c] += level_a * (v*v - level_env_[c]);
      const float rms = std::sqrt(std::max(level_env_[c], 1.0e-9f));
      const float target = 0.20f + level_amt * 0.30f;
      const float gain = std::clamp(target / rms, 0.25f, 4.0f);
      v *= 1.0f + (gain - 1.0f) * 0.12f;
    }
    if (peak) {
      const float ceiling = 0.98f - peak_amt * 0.18f;
      if (std::abs(v) > ceiling) v = std::copysign(ceiling + (1.0f - ceiling) * std::tanh((std::abs(v) - ceiling) / (1.0f - ceiling)), v);
    }
    // Safety clamp is unconditional: malformed or pathological DSP input cannot emit NaN/Inf.
    v = std::isfinite(v) ? std::clamp(v, -1.25f, 1.25f) : 0.0f;
    x[k] = v; maxp = std::max(maxp, std::abs(v));
  }
  output_peak_.store(maxp, std::memory_order_relaxed);
}
} // namespace hush::fx
