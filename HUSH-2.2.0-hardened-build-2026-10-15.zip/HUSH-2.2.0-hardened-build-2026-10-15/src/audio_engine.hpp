#pragma once
/**
 * HUSH 2.2.0 AudioEngine – mid-term integration
 *
 * Session/clip playback (original) + Forensic Rack post-process (new).
 * process() renders the timeline then runs EngineBridge (Spectral De-noise,
 * Hiss Reduction, Click Removal, Hum Eliminator + master gain).
 */
#include "audio.hpp"
#include "result.hpp"
#include "session.hpp"
#include "hush/bridge/EngineBridge.hpp"
#include "hush/forensic/ForensicRack.hpp"
#include "fx_host.hpp"
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <vector>

namespace hush::rt {

class AudioEngine {
 public:
  fk::Status load(const fk::engine::Session& session, const std::filesystem::path& base_dir);
  void play() noexcept { playing_.store(true, std::memory_order_release); }
  void pause() noexcept { playing_.store(false, std::memory_order_release); }
  void stop() noexcept;
  bool playing() const noexcept { return playing_.load(std::memory_order_acquire); }
  std::uint64_t playhead() const noexcept { return playhead_.load(std::memory_order_acquire); }
  fk::Status seek(std::uint64_t frame) noexcept;
  void set_master_gain_db(float db) noexcept;
  fk::Status set_track_gain_db(std::size_t track, float db) noexcept;
  fk::Status set_track_mute(std::size_t track, bool mute) noexcept;

  /// Peak after forensic rack + master (preferred for UI meters)
  float output_peak() const noexcept;

  std::size_t process(float* output, std::size_t frames, std::uint16_t output_channels) noexcept;
  std::uint32_t sample_rate() const noexcept { return sample_rate_; }

  // --- Forensic rack API (binds to UI knobs in the Reconciled rack) ---
  void set_processor_params(hush::fx::Module module, hush::fx::Params params) noexcept { processors_.set_params(module, params); }
  hush::fx::Params processor_params(hush::fx::Module module) const noexcept { return processors_.params(module); }
  hush::fx::ProcessorRack& processors() noexcept { return processors_; }
  const hush::fx::ProcessorRack& processors() const noexcept { return processors_; }

  hush::bridge::EngineBridge& bridge() noexcept { return bridge_; }
  const hush::bridge::EngineBridge& bridge() const noexcept { return bridge_; }

  void set_forensics_enabled(bool on) noexcept { bridge_.setForensicsEnabled(on); }
  bool forensics_enabled() const noexcept { return bridge_.forensicsEnabled(); }

  void set_rack_slot(hush::forensic::Slot slot, bool enabled, float amount, float secondary = 0.f) noexcept {
    bridge_.rack().setParams(slot, {enabled, amount, secondary});
  }
  hush::forensic::SlotParams rack_slot(hush::forensic::Slot slot) const noexcept {
    return bridge_.rack().params(slot);
  }

 private:
  struct ClipData {
    std::uint64_t start{}, source{}, length{}, fade_in{}, fade_out{};
    std::uint16_t channels{};
    std::vector<float> samples;
  };
  struct TrackData {
    std::shared_ptr<std::atomic<float>> gain{std::make_shared<std::atomic<float>>(1.0f)};
    std::shared_ptr<std::atomic<bool>> mute{std::make_shared<std::atomic<bool>>(false)};
    std::vector<ClipData> clips;
  };
  std::vector<TrackData> tracks_;
  std::uint32_t sample_rate_{48000};
  std::uint64_t total_frames_{};
  std::atomic<std::uint64_t> playhead_{0};
  std::atomic<bool> playing_{false};
  std::atomic<float> master_gain_{1.0f};
  std::atomic<float> output_peak_{0.0f};

  hush::bridge::EngineBridge bridge_{};
  hush::fx::ProcessorRack processors_{};
};

class AudioDeviceBackend {
 public:
  using Callback = std::size_t (*)(void* context, float* output, std::size_t frames, std::uint16_t channels) noexcept;
  virtual ~AudioDeviceBackend() = default;
  virtual fk::Status start(std::uint32_t sample_rate, std::uint16_t channels, std::size_t block_frames,
                           Callback callback, void* context) = 0;
  virtual void stop() noexcept = 0;
  virtual const char* name() const noexcept = 0;
};

} // namespace hush::rt
