#pragma once
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace hush::fx {

enum class Maturity : std::uint8_t { Tested, Experimental, OfflineOnly, HostTool };
enum class Module : std::uint8_t { Hum, Smooth, Sibilance, Level, Peak, Noise, Match, Edges, Album, AB, Count };
struct ModuleInfo { Module id; const char* name; Maturity maturity; bool realtime; };
struct Params { bool enabled{false}; float amount{0.5f}; float secondary{0.0f}; };

const std::array<ModuleInfo, static_cast<std::size_t>(Module::Count)>& list_modules() noexcept;

// Allocation-free stereo/mono processor rack. Parameter writes are atomic so UI/control
// threads never take a lock on the audio callback. Stateful DSP remains owned by the audio thread.
class ProcessorRack {
 public:
  ProcessorRack() noexcept;
  void prepare(std::uint32_t sample_rate) noexcept;
  void reset() noexcept;
  void set_params(Module module, Params params) noexcept;
  Params params(Module module) const noexcept;
  void process(float* interleaved, std::size_t frames, std::uint16_t channels) noexcept;
  float output_peak() const noexcept { return output_peak_.load(std::memory_order_relaxed); }
 private:
  struct AtomicParams { std::atomic<bool> enabled{false}; std::atomic<float> amount{0.5f}; std::atomic<float> secondary{0.0f}; };
  std::array<AtomicParams, static_cast<std::size_t>(Module::Count)> params_{};
  std::array<std::array<float, 2>, static_cast<std::size_t>(Module::Count)> state_{};
  std::array<float, 2> hum_x1_{}, hum_x2_{}, hum_y1_{}, hum_y2_{};
  std::array<float, 2> smooth_lp_{}, deess_lp_{}, deess_env_{}, level_env_{};
  std::uint32_t sample_rate_{48000};
  std::atomic<float> output_peak_{0.0f};
};
} // namespace hush::fx
