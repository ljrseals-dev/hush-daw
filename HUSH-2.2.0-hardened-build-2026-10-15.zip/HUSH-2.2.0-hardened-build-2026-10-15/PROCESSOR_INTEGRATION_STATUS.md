# HUSH processor integration status — 2026-10-15

## Integrated
- `AudioEngine` owns `hush::fx::ProcessorRack` and runs it after `EngineBridge::postProcess()` and before the final output peak meter.
- Atomic module parameters are exposed through `set_processor_params()`, `processor_params()`, and `processors()`.
- The callback path is allocation-free within the new rack, supports mono/stereo interleaved float buffers, sanitizes non-finite samples, and keeps all stages disabled by default.
- Real-time DSP stages: Hum (60 Hz notch), Smooth (high-frequency softening), Sibilance (high-band reduction), Level (slow envelope levelling), Peak (soft ceiling), and Noise (experimental downward expander).
- Registry maturity separates real-time modules from offline/host tools. Match is experimental/non-real-time; Edges is offline-only; Album and A/B are host tools. Non-real-time entries are not run by the callback.
- Added `tests/processor_tests.cpp` and preserved the processor repository's MIT notice in `licenses/HUSH_PROCESSOR_MIT.txt`.

## Validation performed
- Full project build completed with GCC 14.2.0, including `hush` and optional `hush_gui`.
- CTest excluding the expensive existing `hush_module_tests`: 8/8 passed, including the new processor test, real-time integration, detector calibration, and CLI smoke test.
- `hush_module_tests` has previously reported 117/117 checks passing, but repeated attempts during this build exceeded the execution window in its computationally expensive watermark-analysis section. Therefore the final package is **not represented as a complete 9/9 test-suite pass**.
- Hardware playback/recording/monitoring has not been validated against a physical device. PortAudio remains opt-in.

## Scope boundary
This package implements the native HUSH real-time rack and its stages; it does not claim to import or execute the separate repository's complete SIMD mixer, a spectral reference-matching engine, album renderer, offline edge analysis, or an external plugin SDK. The `Noise` stage is a conservative expander and is not marketed as AI or spectral denoising.

## Build
```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DHUSH_BUILD_X11_GUI=ON
cmake --build build -j2
ctest --test-dir build --output-on-failure
```
