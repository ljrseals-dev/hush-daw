# HUSH 2.2.0 — hardened build candidate status

Build date: 2026-10-15 local project date (build environment timestamps may roll into 2026-10-16 UTC).
Project version intentionally remains 2.2.0; this is a candidate bundle, not an official version bump.

## Built
- Native `hush` CLI and `hush_gui` X11 application from the included source.
- `HUSH_BUILD_X11_GUI=ON`.
- `HUSH_ENABLE_PORTAUDIO=ON`; CMake found `/usr/lib/x86_64-linux-gnu/libportaudio.so.2`.
- CMake's existing x86_64 hardening flags remain enabled (stack protector, FORTIFY, PIE, RELRO/NOW, no-exec-stack where supported).
- HUSH processor rack is compiled into the real-time library and is included in the test targets.
- No network dependency fetch is used by the CMake build.

## Tests
- Selected Release CTest run: 8/8 passed (audio, realtime, processor, midterm integration, lanes, MSV, detector calibration, CLI smoke).
- GUI smoke: GUI process remained running for 5 seconds under Xvfb with a generated session file; timeout exit 124 is expected for this liveness check.
- Full Release CTest run: the first four tests passed, then `hush_module_tests` exceeded the 120-second command time limit in this run. This is **not** recorded as a full-suite pass. Historical evidence in earlier bundles reported this test passing, but that does not replace the current timed-out run.
- ASan/UBSan targeted run: successfully built and ran audio, processor, and midterm integration test targets; 3/3 passed with `ASAN_OPTIONS=detect_leaks=1` and UBSan stack traces enabled.
- Full ASan/UBSan build attempt: configured with `-fsanitize=address,undefined`; compilation of the entire project exceeded two 300-second execution windows before all targets completed. Therefore this package does **not** claim a completed ASan/UBSan build or sanitizer-clean GUI/full application.

## Important functional boundary
- Physical audio-device playback, capture/recording, and monitoring were not testable in this environment. PortAudio was linked, but the presence of a backend library does not prove a real device works.
- The GUI currently expects a session path (`hush_gui <session.fks>`). Create one with `hush session-new demo.fks 48000 120`.
- HUSH remains the current project's existing 2.2.0 scope; this bundle does not claim a complete commercial DAW feature set or external VST/AU hosting.

## Build again
```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DHUSH_BUILD_X11_GUI=ON -DHUSH_ENABLE_PORTAUDIO=ON -DBUILD_TESTING=ON
cmake --build build -j4
ctest --test-dir build --output-on-failure -E hush_module_tests
```

Run the full module test separately with a generous timeout. To attempt a full ASan/UBSan build independently, configure a separate build directory and record completion only after all targets and tests finish.
