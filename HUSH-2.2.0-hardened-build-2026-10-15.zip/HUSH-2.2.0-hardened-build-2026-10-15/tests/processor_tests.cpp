#include "fx_host.hpp"
#include <cmath>
#include <cstdio>
#include <limits>
#include <vector>

int main() {
  using namespace hush::fx;
  ProcessorRack rack; rack.prepare(48000);
  if (list_modules().size() != static_cast<std::size_t>(Module::Count)) return 1;
  // Default-off processing is transparent for ordinary finite samples.
  std::vector<float> x{0.1f, -0.2f, 0.3f, -0.4f};
  auto original = x; rack.process(x.data(), 2, 2);
  for (std::size_t i=0;i<x.size();++i) if (std::abs(x[i]-original[i]) > 1e-6f) return 2;
  // The peak stage must constrain overs and remain finite.
  rack.set_params(Module::Peak, {true, 1.0f, 0.0f});
  std::vector<float> hot(256, 4.0f); rack.process(hot.data(), 128, 2);
  for (float v : hot) if (!std::isfinite(v) || std::abs(v) > 1.251f) return 3;
  // Experimental/noise and ordinary modules can be toggled without allocations or invalid state.
  rack.set_params(Module::Noise, {true, 0.8f, 0.0f});
  std::vector<float> quiet(128, 0.001f); rack.process(quiet.data(), 128, 1);
  for (float v : quiet) if (!std::isfinite(v)) return 4;
  // Non-finite input is sanitized.
  float bad[] = {std::numeric_limits<float>::quiet_NaN(), std::numeric_limits<float>::infinity()};
  rack.process(bad, 2, 1);
  if (bad[0] != 0.0f || bad[1] != 0.0f) return 5;
  // Offline/host modules remain metadata-only in real-time processing.
  rack.set_params(Module::Edges, {true, 1.0f, 1.0f});
  rack.set_params(Module::Album, {true, 1.0f, 1.0f});
  std::vector<float> safe{0.2f, -0.2f}; rack.process(safe.data(), 2, 1);
  if (std::abs(safe[0]-0.2f)>1e-6f || std::abs(safe[1]+0.2f)>1e-6f) return 6;
  std::puts("processor tests passed"); return 0;
}
