# HUSH module integration audit — 2026-10-15

## Integration path in this build

`hush::rt::AudioEngine::process()` renders the session block, runs the forensic bridge/rack, then runs the processor rack (`hush::fx::ProcessorRack`) before publishing the output peak. The `AudioEngine` owns both racks. The X11 GUI now exposes live controls for the real-time processor modules and the four forensic insert slots.

## Real-time processor modules present

| Module | State in this build | Control path |
|---|---|---|
| Hum | Implemented real-time DSP | GUI tile / `set_processor_params` |
| Smooth | Implemented real-time DSP | GUI tile / `set_processor_params` |
| Sibilance | Implemented real-time DSP | GUI tile / `set_processor_params` |
| Level | Implemented real-time DSP | GUI tile / `set_processor_params` |
| Peak | Implemented real-time DSP | GUI tile / `set_processor_params` |
| Noise | Experimental downward expander; disabled by default | GUI tile / `set_processor_params` |
| Match | Registry entry only; non-real-time | GUI shows HOST status; not falsely enabled as DSP |
| Edges | Registry entry only; offline-only | GUI shows OFFLINE status; not falsely enabled as DSP |
| Album | Registry entry only; host tool | GUI shows HOST status; not falsely enabled as DSP |
| A/B | Registry entry only; host tool | GUI shows HOST status; not falsely enabled as DSP |

## Forensic insert slots

The DAW owns and executes the existing `ForensicRack` through `EngineBridge`: Spectral De-noise, Hiss Reduction, Click Removal, and Hum Eliminator. Their algorithms in this source are lightweight approximations/placeholders, not validated production-grade spectral restoration. They are exposed as a separate row in the GUI; left click toggles a slot and right click raises its amount in 0.1 steps.

## Upstream source limitation — do not overlook

The public `ljrseals-dev/hush-modules` repository currently contains `README.md`, `LICENSE`, image/checksum files, and `hush-midterm-deliverable.zip` (55,494 bytes), but no checked-in `modules/`, `src/`, or `plugins/` source tree matching the nine module implementations described in the README. Its small deliverable is the bridge/forensic-rack integration, not the full advertised AB, Album, Edges, Hum, Level, Match, Noise, Peak, Sibilance, and Smooth implementation set.

Therefore this package wires every implementation actually present in the supplied HUSH processor/DAW source and exposes the existing real-time/forensic controls. It does **not** claim to have recovered absent source code or to have completed the Match, Edges, Album, and A/B algorithms. To finish those modules without inventing replacements, their actual headers, implementation files, plugin wrappers, tests, and license/attribution files must be restored to `hush-modules` or supplied as source.

Upstream repositories audited:
- https://github.com/ljrseals-dev/hush-modules
- https://github.com/ljrseals-dev/hush-processor
- https://github.com/ljrseals-dev/hush-daw
