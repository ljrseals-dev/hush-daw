# HUSH processor integration status — 2026-10-15 (updated)

## Wired into the DAW
- `AudioEngine` owns `hush::bridge::EngineBridge` / `hush::forensic::ForensicRack` and `hush::fx::ProcessorRack`.
- The live output path is: session render -> forensic bridge/rack and master gain -> processor rack -> output peak meter.
- The X11 GUI exposes toggles for the six implemented real-time processor stages (Hum, Smooth, Sibilance, Level, Peak, Noise) and the four forensic insert slots. Right-click increases the selected stage amount by 0.1. UI controls write to the same engine-owned instances used by the callback.
- Match, Edges, Album, and A/B are displayed with HOST/OFFLINE status and are not falsely presented as running real-time processors.

## Validation
- Full Release build succeeded, including `hush` and `hush_gui`.
- Eight selected CTest targets passed (8/8).
- The separate module test executable passed 117/117 checks.
- No physical PortAudio hardware test is claimed; PortAudio is disabled for this verified offline build.

## Important boundary
The upstream `hush-modules` repository does not currently contain the complete source tree described in its README; it contains a 55,494-byte bridge/forensic-rack deliverable. See `docs/MODULE_INTEGRATION_AUDIT.md`. The missing Match, Edges, Album, and A/B implementations cannot be truthfully marked complete without their source. Existing forensic algorithms are lightweight approximations and have not been validated for production-grade restoration quality.
