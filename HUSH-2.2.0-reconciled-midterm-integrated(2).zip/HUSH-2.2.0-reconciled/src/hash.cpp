#include "hash.hpp"
#include <array>
#include <cstdint>
#include <fstream>
#include <vector>
namespace fk::hash {
namespace {
constexpr std::array<std::uint32_t, 64> K = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};
inline std::uint32_t rotr(std::uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
void block(std::array<std::uint32_t, 8>& h, const unsigned char* p) {
  std::array<std::uint32_t, 64> w{};
  for (int i = 0; i < 16; ++i)
    w[i] = (std::uint32_t(p[4 * i]) << 24) | (std::uint32_t(p[4 * i + 1]) << 16) |
           (std::uint32_t(p[4 * i + 2]) << 8) | std::uint32_t(p[4 * i + 3]);
  for (int i = 16; i < 64; ++i) {
    auto s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
    auto s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
    w[i] = w[i - 16] + s0 + w[i - 7] + s1;
  }
  auto a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
  for (int i = 0; i < 64; ++i) {
    auto S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
    auto ch = (e & f) ^ (~e & g);
    auto t1 = hh + S1 + ch + K[i] + w[i];
    auto S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
    auto mj = (a & b) ^ (a & c) ^ (b & c);
    auto t2 = S0 + mj;
    hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
  }
  h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
}
struct Ctx {
  std::array<std::uint32_t, 8> h{0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                                 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
  std::array<unsigned char, 64> buf{};
  std::size_t fill = 0;
  std::uint64_t total = 0;
  void update(const unsigned char* d, std::size_t n) {
    total += n;
    while (n > 0) {
      std::size_t take = std::min<std::size_t>(64 - fill, n);
      for (std::size_t i = 0; i < take; ++i) buf[fill + i] = d[i];
      fill += take; d += take; n -= take;
      if (fill == 64) { block(h, buf.data()); fill = 0; }
    }
  }
  std::string finish() {
    std::uint64_t bits = total * 8;
    unsigned char pad = 0x80;
    update(&pad, 1);
    unsigned char z = 0;
    while (fill != 56) update(&z, 1);
    unsigned char len[8];
    for (int i = 0; i < 8; ++i) len[i] = static_cast<unsigned char>(bits >> (56 - 8 * i));
    update(len, 8);
    static const char* hex = "0123456789abcdef";
    std::string out;
    for (auto v : h)
      for (int i = 28; i >= 0; i -= 4) out.push_back(hex[(v >> i) & 15]);
    return out;
  }
};
}  // namespace
std::string sha256_hex(const unsigned char* data, std::size_t n) {
  Ctx c;
  c.update(data, n);
  return c.finish();
}
Result<std::string> sha256_file(const std::filesystem::path& path) {
  std::ifstream f(path, std::ios::binary);
  if (!f) return Result<std::string>::fail("cannot open file for hashing: " + path.string());
  Ctx c;
  std::vector<unsigned char> buf(1 << 16);
  while (f) {
    f.read(reinterpret_cast<char*>(buf.data()), static_cast<std::streamsize>(buf.size()));
    c.update(buf.data(), static_cast<std::size_t>(f.gcount()));
  }
  return Result<std::string>::success(c.finish());
}
}  // namespace fk::hash
