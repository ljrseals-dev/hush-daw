# HUSH 2.2.0 — Mid-term forensic rack integration

## Integrated path

`hush::rt::AudioEngine` owns `hush::bridge::EngineBridge bridge_`. The engine exposes
`set_rack_slot()`, `rack_slot()`, `set_forensics_enabled()`, and `forensics_enabled()`
for UI/control binding. The rack is compiled into `hush_realtime` via
`src/ForensicRack.cpp` and `src/EngineBridge.cpp`.

After the timeline renderer fills the block, `AudioEngine::process()` now:

1. transfers the current master gain to `EngineBridge`;
2. calls `bridge_.postProcess({out, count, channels})`;
3. publishes the post-rack output peak through `output_peak()`.

Master gain is applied only in the bridge stage, not once per track and again in the
bridge. This avoids accidental double attenuation/amplification.

## Example control binding

```cpp
using hush::forensic::Slot;
engine.set_rack_slot(Slot::SpectralDenoise, true, 0.55f);
engine.set_rack_slot(Slot::HissReduction,   true, 0.40f);
engine.set_rack_slot(Slot::ClickRemoval,    true, 0.65f);
engine.set_rack_slot(Slot::HumEliminator,   true, 0.50f, 0.3f);
```

## Verification performed

- Release configuration and full Linux x86-64 build completed, including `hush` and `hush_gui`.
- CTest: 8/8 tests passed, including the new mid-term API/rack integration smoke test.
- Updated `prebuilt-linux-x86_64/` binaries were copied from that build and their SHA-256 hashes refreshed.

## Scope caveat

This verifies compilation, API binding, and the integration smoke path. It does not establish
perceptual quality, calibrated noise-removal performance, hardware-device behavior, or
production readiness of the lightweight rack algorithms. Run listening tests and hardware
callback validation before a production release.
